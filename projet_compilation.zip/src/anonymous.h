#ifndef __anonymous__
#define __anonymous__

#include "tree.h"
#include "string.h"
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>

#endif 